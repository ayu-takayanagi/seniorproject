<template>
  <div class="library">
    <h1>Library Page</h1>
  </div>
</template>
