<template>
  <div class="monthlyreport">
    <h1>Monthly Report</h1>
  </div>
</template>
