<template>
  <div class="report">
    <h1>Record page</h1>
  </div>
</template>
